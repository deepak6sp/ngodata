// JavaScript Document

function submitForm(){
	document.getElementById('wireframe').submit();	
}